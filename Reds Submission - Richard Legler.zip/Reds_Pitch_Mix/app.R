##### Libraries #####
library(shiny)
library(shinydashboard)
library(ggplot2)
library(DT)
library(dplyr)
library(ggplot2)
library(readr)

##### Pitch Mix Function #####
pitch_mix <- function(year, player) {
  # Filter for player and year
  player_data <- df_pitch[df_pitch$PLAYER_NAME == player & df_pitch$GAME_YEAR == year, ]
  
  # Check if player data exists
  if (nrow(player_data) == 0) {
    # Create a placeholder pie chart for missing data
    return(ggplot() + 
             geom_text(aes(0, 0, label = "Player data not found for the specified year."), size = 6) + 
             theme_void() + 
             theme(plot.title = element_text(hjust = 0.5)))
  }
  
  # Create a data frame for ggplot
  pitch_types <- data.frame(
    Type = c("Fastball", "Breaking Ball", "Off Speed"),
    Value = c(player_data$PITCH_TYPE_FB, player_data$PITCH_TYPE_BB, player_data$PITCH_TYPE_OS)
  )
  
  # Order by Value in descending order
  pitch_types <- pitch_types[order(pitch_types$Value), ]
  
  # Set Type as a factor with levels in the order of Value
  pitch_types$Type <- factor(pitch_types$Type, levels = pitch_types$Type)
  
  # Set colors
  colors <- c("Fastball" = "red", "Breaking Ball" = "blue", "Off Speed" = "green")
  
  # Calculate percentages
  pitch_types$Percentage <- round((pitch_types$Value / sum(pitch_types$Value)) * 100, 1)
  
  # Create pie chart
  pie_chart <- ggplot(data = pitch_types, aes(x = "", y = Value, fill = Type)) +
    geom_bar(stat = "identity", width = 1) +
    coord_polar("y") +
    scale_fill_manual(values = colors) +
    labs(title = ifelse(year == 2024, paste("Predicted", year, "Pitch Mix"), paste(year, "Pitch Mix"))) +
    theme_void() +
    geom_text(aes(label = paste(Percentage, "%", sep = "")), position = position_stack(vjust = 0.5), color = "black") +
    theme(plot.title = element_text(hjust = 0.5))
  
  return(pie_chart)
}

##### Season Stat Function #####
stat_summary <- function(year, player) {
  # Filter for player and year
  player_data <- df_player_season[df_player_season$PLAYER_NAME == player & df_player_season$GAME_YEAR == year, ]
  
  # Check if player data exists
  if (nrow(player_data) == 0) {
    # Create a placeholder data table for missing data
    return(datatable(data.frame(Message = "Player data not found for the specified year."),
                     options = list(pageLength = 3, autoWidth = TRUE, dom = 't')))
  }
  
  # Create summary table
  summary_table <- data.frame(
    Pitch_Type = c("Fastball", "Breaking Ball", "Off Speed"),
    WOBA = round(c(player_data$WOBA_FB, player_data$WOBA_BB, player_data$WOBA_OS), 3),
    Estimated_WOBA = round(c(player_data$ESTIMATED_WOBA_FB, player_data$ESTIMATED_WOBA_BB, player_data$ESTIMATED_WOBA_OS), 3)
  )
  
  # Return the summary table as a datatable
  return(datatable(summary_table, options = list(pageLength = 3, autoWidth = TRUE, dom = 't')))
}

##### Import Data #####
df_pitch <- read_csv("pitch_mix.csv", show_col_types = FALSE)
df_player_season <- read_csv("season_stats.csv", show_col_types = FALSE)

##### UI #####
ui <- dashboardPage(
  dashboardHeader(title = "Player Pitch Mix Analysis"),
  dashboardSidebar(
    selectInput("player_name", 
                "Select Player:", 
                choices = unique(df_pitch$PLAYER_NAME), 
                selected = unique(df_pitch$PLAYER_NAME)[1])
  ),
  dashboardBody(
    fluidRow(
      column(12, align = "center", htmlOutput("title"))
    ),
    fluidRow(
      column(3, plotOutput("pie_chart_2021")),
      column(3, plotOutput("pie_chart_2022")),
      column(3, plotOutput("pie_chart_2023")),
      column(3, plotOutput("pie_chart_2024"))
    ),
    fluidRow(
      column(3, dataTableOutput("summary_table_2021")),
      column(3, dataTableOutput("summary_table_2022")),
      column(3, dataTableOutput("summary_table_2023")),
      column(3, "")  # Empty space for alignment
    )
  )
)

##### Server #####
server <- function(input, output) {
  # Title
  output$title <- renderUI({
    h3(input$player_name)
  })
  
  # Generate pie charts for each year
  output$pie_chart_2021 <- renderPlot({
    pitch_mix(2021, input$player_name)
  })
  
  output$pie_chart_2022 <- renderPlot({
    pitch_mix(2022, input$player_name)
  })
  
  output$pie_chart_2023 <- renderPlot({
    pitch_mix(2023, input$player_name)
  })
  
  output$pie_chart_2024 <- renderPlot({
    pitch_mix(2024, input$player_name)
  })
  
  # Generate summary tables for each year
  output$summary_table_2021 <- renderDataTable({
    stat_summary(2021, input$player_name)
  })
  
  output$summary_table_2022 <- renderDataTable({
    stat_summary(2022, input$player_name)
  })
  
  output$summary_table_2023 <- renderDataTable({
    stat_summary(2023, input$player_name)
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
